e_perpus/
├── public/
│   ├── index.php        → Front Controller (Router)
│   └── assets/          → CSS, JS, Gambar
├── src/
│   ├── config/
│   │   └── Database.php → Koneksi PDO
│   ├── controllers/     → Business Logic
│   ├── models/          → Database Queries
│   └── views/           → Tampilan HTML
└── perpus_satu.sql      → File Database Schema